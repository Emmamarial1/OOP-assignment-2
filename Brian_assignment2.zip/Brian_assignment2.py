#Question 1
class Device:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model
        
    def show_info(self):
        print(f"Brand: {self.brand}")
        print(f"model: {self.model}")
        
        
class smartphone (Device):
    def __init__(self, brand, model, storage_capacity):
        super().__init__(brand, model)
        self.storage_capacity = storage_capacity
        
    def show_info(self):
        print(f"Storage capacity: {self.storage_capacity}")
            
            
device1 = Device("Samson", "S20 ultra")
smartphone1 = smartphone("samson", "s20", "256 gb")


device1.show_info()
smartphone1.show_info()








#Question2


class Camera:
    def take_photo(self):
        print("Taking a photo...")


class Phone:
    def make_call(self):
        print("Making a phone call...")


class Smartphone(Camera, Phone):
    pass

my_smartphone = Smartphone()

# Call both methods
my_smartphone.take_photo()
my_smartphone.make_call()




#Question3


class Vehicle:
    def __init__(self, vehicle_type):
        self.vehicle_type = vehicle_type
         
         
    def start(self):
        print(f"start: starting the car.....")
        
class Car (Vehicle):
    def __init__(self, vehicle_type, numberOfDoor):
        super().__init__(vehicle_type)
        self.numberOfDoor = numberOfDoor
         
    def display_doors(self):
        print(f"number of  door: {self.numberOfDoor}")
            
         
class ElectricCar(Car):
    def __init__(self, vehicle_type, numberOfDor, battery_capacity):
        super().__init__(vehicle_type, numberOfDor)
        self.battery_capacity = battery_capacity
        
    def  display_batteryPower(self):
        print(self.numberOfDoor, self.battery_capacity)
    

        
my_car = ElectricCar("texic", "4doors", "40000MAh")


my_car.display_doors()
my_car.display_batteryPower()
my_car.start()
        
        
        
        
        
#question4


class employee:
    def work(self):
        print("employee is working")
        
        
class manager (employee):
    def work(self):
        print('manager is managing team of workers')
        
        
class developer(employee):
    def work(self):
        print('developer is coding.....')
        
        
developer= developer()
manager = manager()

manager.work()
developer.work()
        
        
   
   
   
# question 5


class Applicance:
    def __init__(self, brand, power):
        self.brand = brand
        self.power = power
        
    def show_details(self):
        print(self.brand, self.power)
        
    
    
class washingMachine(Applicance):
    def __init__(self, brand, power, drum_size):
        super().__init__(brand, power)
        self.drum_size = drum_size
        
        
    def show_details(self):
        print(f"Brand: {self.brand} ")
        print(f"Power: {self.power} ")
        print("Drum_size: {self.drum_size} ")
        
        
my_washingMachine = washingMachine("Apple", "3000MAh", "79Km")

my_washingMachine.show_details()



    
    
    
    
    
#question 6

class Animals:
    def sound(self):
        print("Some generic animal sound")


class Dog(Animals):
    def sound(self):
        print("Bark!...")
        
        
class Cat(Animals):
    def sound(self):
        print("Meow")
        
    def make_animal_sound(Animals):
        Animals.sound()
        
Aniaml = Animals()        
dog = Dog()
cat = Cat()

dog.sound()
cat.sound()
cat.make_animal_sound()
Aniaml.sound()



#Question 7
class Device:
    def info(self):
        print("Device information")
        
class computer(Device):
    def info(self):
        print("computer information")
        
class laptop(computer):
    def info(self):
        print("laptop information")
        
computer1 = computer()
laptop1 = laptop()


computer1.info()
laptop1.info()

    



    